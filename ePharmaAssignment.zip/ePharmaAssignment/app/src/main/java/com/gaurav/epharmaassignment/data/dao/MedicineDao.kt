package com.gaurav.epharmaassignment.data.dao

import android.arch.lifecycle.LiveData
import android.arch.persistence.room.*
import com.gaurav.epharmaassignment.data.entity.Medicine

@Dao
interface MedicineDao {

    @Insert
    suspend fun saveMedicine(todoRecord: Medicine)

    @Delete
    suspend fun deleteMedicine(todoRecord: Medicine)

    @Update
    suspend fun updateMedicine(todoRecord: Medicine)

    @Query("SELECT * FROM medicine ORDER BY id DESC")
    fun getAllMedicine(): LiveData<List<Medicine>>
}