package com.gaurav.epharmaassignment.data

import android.arch.persistence.room.Database
import android.arch.persistence.room.Room
import android.arch.persistence.room.RoomDatabase
import android.content.Context
import com.gaurav.epharmaassignment.data.dao.MedicineDao
import com.gaurav.epharmaassignment.data.entity.Medicine

@Database(entities = [Medicine::class], version = 1, exportSchema = false)
abstract class MedicineDatabase : RoomDatabase() {

    abstract fun medicineDao(): MedicineDao

    companion object {
        private var INSTANCE: MedicineDatabase? = null

        fun getInstance(context: Context): MedicineDatabase? {
            if (INSTANCE == null) {
                synchronized(MedicineDatabase::class) {
                    INSTANCE = Room.databaseBuilder(context,
                        MedicineDatabase::class.java,
                        "medicine_db")
                        .build()
                }
            }
            return INSTANCE
        }
    }
}