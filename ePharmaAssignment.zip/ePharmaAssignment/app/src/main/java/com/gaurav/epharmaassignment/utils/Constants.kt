package com.gaurav.epharmaassignment.utils

object Constants {

    const val INTENT_OBJECT = "medicine_object"
    const val INTENT_CREATE_MEDICINE = 1
    const val INTENT_UPDATE_MEDICINE = 2
}