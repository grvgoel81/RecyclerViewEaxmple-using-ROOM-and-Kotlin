package com.gaurav.epharmaassignment.data.entity

import android.arch.persistence.room.ColumnInfo
import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Entity(tableName = "medicine")
@Parcelize
data class Medicine(@PrimaryKey(autoGenerate = true) val id: Long?,
                    @ColumnInfo(name = "name") val name: String,
                    @ColumnInfo(name = "description") val description: String,
                    @ColumnInfo(name = "quantity") val quantity: Int,
                    @ColumnInfo(name = "price") val price: Double) : Parcelable